def mergeDict(x, y):
    o = x.copy()
    o.update(y)
    return o